# TB6612FNG

Dois motores por canal só devem ser usados quando a corrente combinada, especialmente a corrente de partida/travamento, estiver dentro da capacidade do módulo e do driver.
