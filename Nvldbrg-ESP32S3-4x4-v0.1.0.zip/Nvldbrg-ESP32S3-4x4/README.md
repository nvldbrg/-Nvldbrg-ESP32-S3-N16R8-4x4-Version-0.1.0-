# Nvldbrg ESP32-S3 N16R8 4x4

Projeto de carrinho 4x4 com ESP32-S3 N16R8 UNO-compatible, TB6612FNG e quatro motores.

## v0.1.0
- Modo tanque
- Giro 360° no próprio eixo
- Controle Wi-Fi por navegador
- Dois joysticks
- Failsafe de 1 segundo
- PWM 20 kHz / 8 bits
- API LEDC atual do Arduino-ESP32 3.x

## Pinagem

| TB6612FNG | GPIO | UNO |
|---|---:|---|
| PWMA | GPIO17 | D3 |
| AIN1 | GPIO18 | D2 |
| AIN2 | GPIO21 | D8 |
| PWMB | GPIO14 | D7 |
| BIN1 | GPIO38 | extra |
| BIN2 | GPIO39 | extra |
| STBY | GPIO10 | D10 |
| VCC | 3V3 | — |
| GND | GND | — |
| VM | bateria dos motores | — |

GPIO19 e GPIO20 ficam livres para eventual USB nativo.

## Wi-Fi
SSID: `CARRINHO_4X4`
Senha: `12345678`
Endereço: `192.168.4.1`

## Ligação dos motores
Canal A: motor dianteiro esquerdo + traseiro esquerdo.
Canal B: motor dianteiro direito + traseiro direito.

Confira a corrente de partida/travamento dos dois motores de cada lado antes de ligá-los em paralelo ao mesmo canal.

## Alimentação
VM recebe a alimentação dos motores. Não alimente os motores pelo 3V3 da ESP32. Una os GNDs.

## Estrutura
```text
Nvldbrg-ESP32S3-4x4/
├── README.md
├── LICENSE
├── CHANGELOG.md
├── src/Nvldbrg_4x4.ino
├── docs/pinout.md
├── docs/wiring.md
├── docs/architecture.md
└── hardware/tb6612fng.md
```

## Próximas versões
- Xbox 360
- BLE
- aceleração progressiva
- telemetria
- bateria
- iluminação e buzina

## Licença
MIT
