# Wiring

VCC do TB6612 -> 3V3. GND -> GND comum. VM -> bateria dos motores. STBY -> GPIO10.

Canal A: motores do lado esquerdo. Canal B: motores do lado direito.
