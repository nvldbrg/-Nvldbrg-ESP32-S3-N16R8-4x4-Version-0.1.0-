# Architecture

Tank drive: esquerda e direita são controladas independentemente. (200,200)=frente; (-200,-200)=ré; (-220,220)=giro; (220,-220)=giro oposto; (0,0)=parada.
