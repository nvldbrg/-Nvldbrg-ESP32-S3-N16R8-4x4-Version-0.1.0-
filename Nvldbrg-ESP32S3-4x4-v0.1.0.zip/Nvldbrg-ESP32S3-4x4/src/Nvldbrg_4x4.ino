/*
 * Nvldbrg ESP32-S3 N16R8 4x4
 * Version 0.1.0
 * ESP32-S3 N16R8 UNO + TB6612FNG + 4 motors
 */

#include <WiFi.h>
#include <WebServer.h>

constexpr char WIFI_SSID[] = "CARRINHO_4X4";
constexpr char WIFI_PASSWORD[] = "12345678";

WebServer server(80);

// TB6612FNG pinout
constexpr uint8_t PWMA = 17;  // UNO D3
constexpr uint8_t AIN1 = 18;  // UNO D2
constexpr uint8_t AIN2 = 21;  // UNO D8
constexpr uint8_t PWMB = 14;  // UNO D7
constexpr uint8_t BIN1 = 38;  // extra GPIO
constexpr uint8_t BIN2 = 39;  // extra GPIO
constexpr uint8_t STBY = 10;  // UNO D10

constexpr uint32_t PWM_FREQUENCY = 20000;
constexpr uint8_t PWM_RESOLUTION = 8;
constexpr uint16_t FAILSAFE_MS = 1000;

int currentLeft = 0;
int currentRight = 0;
unsigned long lastCommandMs = 0;

void setLeftMotor(int speed) {
  speed = constrain(speed, -255, 255);
  if (speed > 0) {
    digitalWrite(AIN1, HIGH);
    digitalWrite(AIN2, LOW);
    ledcWrite(PWMA, speed);
  } else if (speed < 0) {
    digitalWrite(AIN1, LOW);
    digitalWrite(AIN2, HIGH);
    ledcWrite(PWMA, -speed);
  } else {
    digitalWrite(AIN1, LOW);
    digitalWrite(AIN2, LOW);
    ledcWrite(PWMA, 0);
  }
}

void setRightMotor(int speed) {
  speed = constrain(speed, -255, 255);
  if (speed > 0) {
    digitalWrite(BIN1, HIGH);
    digitalWrite(BIN2, LOW);
    ledcWrite(PWMB, speed);
  } else if (speed < 0) {
    digitalWrite(BIN1, LOW);
    digitalWrite(BIN2, HIGH);
    ledcWrite(PWMB, -speed);
  } else {
    digitalWrite(BIN1, LOW);
    digitalWrite(BIN2, LOW);
    ledcWrite(PWMB, 0);
  }
}

void stopMotors() {
  currentLeft = 0;
  currentRight = 0;
  setLeftMotor(0);
  setRightMotor(0);
}

void tankDrive(int left, int right) {
  currentLeft = constrain(left, -255, 255);
  currentRight = constrain(right, -255, 255);
  setLeftMotor(currentLeft);
  setRightMotor(currentRight);
  lastCommandMs = millis();
}

const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!doctype html><html lang="pt-BR"><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nvldbrg 4x4</title>
<style>
body{background:#111;color:#eee;font-family:Arial;text-align:center;margin:18px}
h1{color:#00ff88}.wrap{display:flex;justify-content:center;gap:28px;flex-wrap:wrap}
.joy{width:180px;height:180px;border-radius:50%;background:#333;position:relative;touch-action:none}
.knob{width:60px;height:60px;border-radius:50%;background:#00ff88;position:absolute;left:60px;top:60px}
button{width:145px;height:48px;margin:7px;border:0;border-radius:10px;font-size:16px}
.stop{background:#d22;color:white}small{color:#aaa}
</style></head><body>
<h1>NVLDBRG 4x4</h1><p>ESP32-S3 N16R8 + TB6612FNG</p>
<div class="wrap">
<div><p>ESQUERDO</p><div class="joy" id="jl"><div class="knob" id="kl"></div></div></div>
<div><p>DIREITO</p><div class="joy" id="jr"><div class="knob" id="kr"></div></div></div>
</div>
<p><button onclick="cmd('frente')">⬆ FRENTE</button>
<button onclick="cmd('re')">⬇ RÉ</button><br>
<button onclick="cmd('esq')">↺ 360° ESQ.</button>
<button onclick="cmd('dir')">↻ 360° DIR.</button><br>
<button class="stop" onclick="cmd('stop')">🛑 PARAR</button></p>
<small>Modo tanque: cada joystick controla um lado.</small>
<script>
let L=0,R=0;
function send(){fetch(`/controle?l=${L}&r=${R}`).catch(()=>{});}
function cmd(c){fetch(`/comando?c=${c}`).catch(()=>{});}
function setup(joyId,knobId,side){
 const joy=document.getElementById(joyId),knob=document.getElementById(knobId);let active=false;
 function move(x,y){
  const r=joy.getBoundingClientRect();let dx=x-(r.left+r.width/2),dy=y-(r.top+r.height/2);
  const lim=r.width/2-30,d=Math.hypot(dx,dy);if(d>lim){dx=dx/d*lim;dy=dy/d*lim;}
  knob.style.left=(60+dx)+'px';knob.style.top=(60+dy)+'px';
  let v=-Math.round(dy/lim*255);if(Math.abs(v)<25)v=0;if(side==='L')L=v;else R=v;send();
 }
 joy.onpointerdown=e=>{active=true;joy.setPointerCapture(e.pointerId);move(e.clientX,e.clientY);}
 joy.onpointermove=e=>{if(active)move(e.clientX,e.clientY);}
 joy.onpointerup=()=>{active=false;knob.style.left='60px';knob.style.top='60px';if(side==='L')L=0;else R=0;send();}
}
setup('jl','kl','L');setup('jr','kr','R');
</script></body></html>
)rawliteral";

void handleRoot() { server.send_P(200, "text/html", INDEX_HTML); }

void handleControl() {
  int left = server.hasArg("l") ? server.arg("l").toInt() : 0;
  int right = server.hasArg("r") ? server.arg("r").toInt() : 0;
  tankDrive(left, right);
  server.send(200, "text/plain", "OK");
}

void handleCommand() {
  const String command = server.arg("c");
  if (command == "frente") tankDrive(200, 200);
  else if (command == "re") tankDrive(-200, -200);
  else if (command == "esq") tankDrive(-220, 220);
  else if (command == "dir") tankDrive(220, -220);
  else if (command == "stop") stopMotors();
  server.send(200, "text/plain", "OK");
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(STBY, OUTPUT);
  digitalWrite(STBY, HIGH);

  ledcAttach(PWMA, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcAttach(PWMB, PWM_FREQUENCY, PWM_RESOLUTION);
  stopMotors();

  WiFi.mode(WIFI_AP);
  WiFi.softAP(WIFI_SSID, WIFI_PASSWORD);

  Serial.println("\n=== Nvldbrg ESP32-S3 4x4 ===");
  Serial.print("SSID: "); Serial.println(WIFI_SSID);
  Serial.print("IP: "); Serial.println(WiFi.softAPIP());

  server.on("/", handleRoot);
  server.on("/controle", handleControl);
  server.on("/comando", handleCommand);
  server.begin();
  lastCommandMs = millis();
}

void loop() {
  server.handleClient();
  if (millis() - lastCommandMs > FAILSAFE_MS &&
      (currentLeft != 0 || currentRight != 0)) {
    stopMotors();
  }
}
