# Changelog

## 0.1.0 - 2026-09-23
- Primeira versão do projeto.
- Controle tanque 4x4.
- Wi-Fi e interface web.
- Failsafe.
